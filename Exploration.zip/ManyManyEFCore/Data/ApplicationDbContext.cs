﻿using ManyManyEFCore.Configurations;
using ManyManyEFCore.Configurations.DataModels;
using ManyManyEFCore.DataModels;
using ManyManyEFCore.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ManyManyEFCore.Data
{
    public class ApplicationDbContext : Microsoft.EntityFrameworkCore.DbContext
    {
        //default models
        //public DbSet<School> Schools { get; set; }
        //public DbSet<Student> Students { get; set; }
        //public DbSet<Lesson> Lessons { get; set; }

        //special database models for many to many
        public DbSet<SchoolData> Schools { get; set; }
        public DbSet<StudentData> Students { get; set; }
        public DbSet<LessonData> Lessons { get; set; }
        public DbSet<StudentLessonData> StudentLessons { get; set; }

        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options)
        {
        }

        

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            //default models
            //modelBuilder.ApplyConfiguration(new SchoolConfiguration());
            //modelBuilder.ApplyConfiguration(new LessonConfiguration());
            //modelBuilder.ApplyConfiguration(new StudentConfiguration());

            //special database models for many to many
            modelBuilder.ApplyConfiguration(new SchoolDataConfiguration());
            modelBuilder.ApplyConfiguration(new LessonDataConfiguration());
            modelBuilder.ApplyConfiguration(new StudentDataConfiguration());
            modelBuilder.ApplyConfiguration(new StudentLessonDataConfiguration());

            base.OnModelCreating(modelBuilder);
        }
    }
}
