﻿using AutoMapper;
using ManyManyEFCore.DataModels;
using ManyManyEFCore.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ManyManyEFCore.MapperProfiles
{
    public class DbProfile : Profile
    {
        public DbProfile()
        {
            CreateMap<School, SchoolData>().ReverseMap();


            //CreateMap<StudentData, Student>().ForMember(s => s.Name, sd => sd.MapFrom(src => src.FirstName + " " + src.LastName));

            //reateMap<StudentData, Student>().ForMember(sd => sd.
            //CreateMap<Student, StudentData>().ForMember(sd => sd.StudentLessons.ForEach(sld => sld.Lesson.Id)

            //CreateMap<Student, StudentData>().ForMember(sd => sd.StudentLessons, s => s.MapFrom(src => src.Lessons.Select( l => )
            CreateMap<StudentLessonData, Student>().ForMember(s => s.Lessons, sld => sld.MapFrom(src => src.Lesson));
            //CreateMap<Student, StudentLessonData>()
            //    .ForMember(sld => sld.Lesson, s => s.MapFrom(src => src.Lessons))
            //    .ForMember(sld => sld.LessonId, s=> s.MapFrom(src => src.le))


            CreateMap<StudentData, Student>().ForMember(sd => sd.Lessons, s => s.MapFrom(src => src.StudentLessons.Select(sl => sl.Lesson).ToList()));
            CreateMap<Student, StudentData>().ForMember(s => s.StudentLessons, sd => sd.MapFrom(src => src.Lessons.ForEach(lesson => new StudentLessonData() { Lesson = lesson }));
        }
    }
}
