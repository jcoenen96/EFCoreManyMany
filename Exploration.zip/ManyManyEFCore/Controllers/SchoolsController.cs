﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using ManyManyEFCore.Data;
using ManyManyEFCore.DataModels;

namespace ManyManyEFCore.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class SchoolsController : ControllerBase
    {
        private readonly ApplicationDbContext _context;

        public SchoolsController(ApplicationDbContext context)
        {
            _context = context;
        }

        // GET: api/Schools
        [HttpGet]
        public IEnumerable<SchoolData> GetSchools()
        {
            return _context.Schools;
        }

        // GET: api/Schools/5
        [HttpGet("{id}")]
        public async Task<IActionResult> GetSchoolData([FromRoute] int id)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            throw new NotImplementedException();
        }

        // PUT: api/Schools/5
        [HttpPut("{id}")]
        public async Task<IActionResult> PutSchoolData([FromRoute] int id, [FromBody] SchoolData schoolData)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }


            throw new NotImplementedException();
            return NoContent();
        }

        // POST: api/Schools
        [HttpPost]
        public async Task<IActionResult> PostSchoolData([FromBody] SchoolData schoolData)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }


            throw new NotImplementedException();
            return CreatedAtAction("GetSchoolData", new { id = schoolData.Id }, schoolData);
        }

        // DELETE: api/Schools/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteSchoolData([FromRoute] int id)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }



            throw new NotImplementedException();
        }

        private bool SchoolDataExists(int id)
        {
            throw new NotImplementedException();
        }
    }
}