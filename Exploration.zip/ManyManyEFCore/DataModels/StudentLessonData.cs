﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ManyManyEFCore.DataModels
{
    public class StudentLessonData
    {
        public int StudentId { get; set; }
        public StudentData Student { get; set; }
        public int LessonId { get; set; }
        public LessonData Lesson { get; set; }
    }
}
