﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ManyManyEFCore.Repository.Pattern
{
    public interface IRepository<TReturnEntity, TDatabaseEntity> 
        where TReturnEntity : class
        where TDatabaseEntity : class
    {
        Task<TReturnEntity> FindAsync(int id);
        Task AddAsync(TDatabaseEntity entity);
        Task AddRangeAsync(IEnumerable<TDatabaseEntity> entities);
        void Update(TDatabaseEntity entity);
        Task RemoveAsync(int id);
        void Remove(TDatabaseEntity entity);
    }
}
