﻿using AutoMapper;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ManyManyEFCore.Repository.Pattern
{
    public abstract class Repository<TReturnEntity, TDatabaseEntity> : IRepository<TReturnEntity, TDatabaseEntity>
        where TReturnEntity : class
        where TDatabaseEntity : class
    {
        protected DbContext DbContext { get; }
        protected DbSet<TDatabaseEntity> DbSet => DbContext.Set<TDatabaseEntity>();
        protected DbSet<T> GetDbSet<T>() where T : class
        {
            return DbContext.Set<T>();
        }

        protected IUnitOfWork UnitOfWork { get; }

        protected IMapper AutoMapper { get; }

        public Repository(DbContext dbContext, IUnitOfWork unitOfWork, IMapper mapper)
        {
            DbContext = dbContext;
            UnitOfWork = unitOfWork;
            AutoMapper = mapper;
        }

        public async Task<TReturnEntity> FindAsync(int id)
        {
            return AutoMapper.Map<TDatabaseEntity, TReturnEntity>(await DbSet.FindAsync(id));
        }

        private async Task<TDatabaseEntity> FindDbEntityAsync(int id)
        {
            return await DbSet.FindAsync(id);
        }

        public virtual async Task AddAsync(TDatabaseEntity entity)
        {
            await DbSet.AddAsync(entity);
        }

        public virtual async Task AddRangeAsync(IEnumerable<TDatabaseEntity> entities)
        {
            await DbSet.AddRangeAsync(entities);
        }

        public virtual void Update(TDatabaseEntity entity)
        {
            DbSet.Attach(entity);
            DbSet.Update(entity);
        }

        public virtual async Task RemoveAsync(int id)
        {
            TDatabaseEntity entity = await FindDbEntityAsync(id);
            if (entity == null) { throw new KeyNotFoundException($"Id: {id} not found"); }
            Remove(entity);
        }

        public virtual void Remove(TDatabaseEntity entity)
        {
            if (DbContext.Entry(entity).State == EntityState.Detached) { DbSet.Attach(entity); }
            DbSet.Remove(entity);
        }
    }
}
